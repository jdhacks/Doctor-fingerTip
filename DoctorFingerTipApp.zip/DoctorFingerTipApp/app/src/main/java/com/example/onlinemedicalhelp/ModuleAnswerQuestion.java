package com.example.onlinemedicalhelp;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.onlinemedicalhelp.Database.DatabaseAccess;
import com.example.onlinemedicalhelp.helper.PreferenceHelper;
import com.example.onlinemedicalhelp.helper.SharedPrefHelper;
import com.example.onlinemedicalhelp.models.AnsModel;
import com.example.onlinemedicalhelp.models.DocModel;
import com.example.onlinemedicalhelp.models.QuestionModel;

import java.util.ArrayList;
import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import butterknife.BindView;
import butterknife.ButterKnife;

public class ModuleAnswerQuestion extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;


    public SharedPreferences sp;
    public SharedPrefHelper dataprocessor;

    DatabaseAccess db;
    @BindView(R.id.lblquestion)
    TextView lblquestion;
    @BindView(R.id.spinner_selectque)
    Spinner spinnerSelectque;
    @BindView(R.id.lblanswer)
    TextView lblanswer;
    @BindView(R.id.edtanswer)
    EditText edtanswer;
    @BindView(R.id.lblquestiondate)
    TextView lblquestiondate;
    @BindView(R.id.edtansdate)
    TextView edtansdate;
    @BindView(R.id.btnanswer)
    Button btnanswer;

    public static int itemposition = 0;
    public static String SelectedQuestion = "Select Question";
    public ArrayList<String> questionarray = new ArrayList<>();
    public ArrayList<QuestionModel> questionarraymodels = new ArrayList<>();
    @BindView(R.id.lblquestion1)
    TextView lblquestion1;
    @BindView(R.id.txtquestion)
    TextView txtquestion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module_answer_question);
        ButterKnife.bind(this);
        toolbar.setTitle("Answer Any Queries Here");
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        db = DatabaseAccess.getInstance(this);//new Database(ModuleAnswerQuestion.this);
        sp = getSharedPreferences("medical_pref", MODE_PRIVATE);
        dataprocessor = new SharedPrefHelper(ModuleAnswerQuestion.this);

        db.open();
        questionarraymodels.addAll(db.getAllQuestionData());
        db.close();

        if (questionarraymodels.size() > 0) {
            if (questionarray.size() > 0) {
                questionarray.clear();

            }
            questionarray.add("Select Questions");
            for (int i = 0; i < questionarraymodels.size(); i++) {
                questionarray.add(questionarraymodels.get(i).getQues_que());
            }
        }
        edtansdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mcurrentDate = Calendar.getInstance();
                int mYear = mcurrentDate.get(Calendar.YEAR);
                int mMonth = mcurrentDate.get(Calendar.MONTH);
                int mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker = new DatePickerDialog(ModuleAnswerQuestion.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                        edtansdate.setText(selectedday + "/" + selectedmonth + "/" + selectedyear);
                    }
                }, mYear, mMonth, mDay);
                mDatePicker.setTitle("Select date");
                mDatePicker.show();
            }
        });
        txtquestion.setMovementMethod(new ScrollingMovementMethod());
        spinnerSelectque.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                itemposition = i;
                SelectedQuestion = adapterView.getSelectedItem().toString();
                txtquestion.setText(SelectedQuestion);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        ArrayAdapter dataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, questionarray);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerSelectque.setAdapter(dataAdapter);


        btnanswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtansdate.getText().toString().equals("")) {
                    Toast.makeText(ModuleAnswerQuestion.this, "Date should not be Empty", Toast.LENGTH_LONG).show();
                } else if (edtanswer.getText().toString().equals("")) {
                    Toast.makeText(ModuleAnswerQuestion.this, "Question should not be Empty", Toast.LENGTH_LONG).show();
                } else if (spinnerSelectque.getSelectedItem().toString().equals("")) {
                    Toast.makeText(ModuleAnswerQuestion.this, "Subject should be Selected", Toast.LENGTH_LONG).show();
                } else {

                    DocModel pm = new DocModel();
                    db.open();
                    if (db.getThisDoctorData(dataprocessor.getString(PreferenceHelper.LoginEmailid)) != null) {
                        pm = db.getThisDoctorData(dataprocessor.getString(PreferenceHelper.LoginEmailid));
                    }

                    AnsModel am = new AnsModel();
                    am.setAns_date(edtansdate.getText().toString().trim());
                    am.setAns_treviews("0");
                    am.setAns_qansid(questionarraymodels.get(itemposition - 1).getQues_ID().toString());
                    am.setAns_que(SelectedQuestion);
                    am.setAns_sub(edtanswer.getText().toString().trim());
                    StringBuilder sb = new StringBuilder();
                    sb.append("d");
                    sb.append(pm.DOCTOR_ID);
                    am.setAns_quid(sb.toString());
                    db.AddAnswerData(am);
                    QuestionModel qm = new QuestionModel();
                    qm = questionarraymodels.get(itemposition - 1);
                    int ans = Integer.parseInt(qm.getQues_tanswers());
                    ans++;
                    qm.setQues_tanswers(String.valueOf(ans));
                    db.UpDateQuestionData(qm);
                    db.close();
                    Toast.makeText(ModuleAnswerQuestion.this, "Answer Submitted", Toast.LENGTH_LONG).show();
                    finish();

                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater();
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return false;
        //return super.onOptionsItemSelected(item);
    }
}
