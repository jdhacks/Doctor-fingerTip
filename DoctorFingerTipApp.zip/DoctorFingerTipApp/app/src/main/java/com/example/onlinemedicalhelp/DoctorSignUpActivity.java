package com.example.onlinemedicalhelp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.onlinemedicalhelp.Database.DatabaseAccess;
import com.example.onlinemedicalhelp.helper.PreferenceHelper;
import com.example.onlinemedicalhelp.helper.SharedPrefHelper;
import com.example.onlinemedicalhelp.models.DocModel;

import java.util.Calendar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import butterknife.BindView;
import butterknife.ButterKnife;

public class DoctorSignUpActivity extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.lblemailid)
    TextView lblemailid;
    @BindView(R.id.edtemailid)
    EditText edtemailid;
    @BindView(R.id.lblname)
    TextView lblname;
    @BindView(R.id.edtname)
    EditText edtname;
    @BindView(R.id.lblmobile)
    TextView lblmobile;
    @BindView(R.id.edtmobile)
    EditText edtmobile;
    @BindView(R.id.lblbdate)
    TextView lblbdate;
    @BindView(R.id.edtbdate)
    TextView edtbdate;
    @BindView(R.id.lblage)
    TextView lblage;
    @BindView(R.id.lblqualification)
    TextView lblqualification;
    @BindView(R.id.edtqualification)
    EditText edtqualification;
    @BindView(R.id.btnsignup)
    Button btnsignup;

    @BindView(R.id.lblpassword)
    TextView lblpassword;
    @BindView(R.id.edtpassword)
    EditText edtpassword;
    @BindView(R.id.edtage)
    TextView edtage;

    public SharedPreferences sp;
    public SharedPrefHelper dataprocessor;

    DatabaseAccess db;
    @BindView(R.id.lblSpeciality)
    TextView lblSpeciality;
    @BindView(R.id.edtSpeciality)
    EditText edtSpeciality;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_sign_up);
        ButterKnife.bind(this);

        toolbar.setTitle("Join Our Doctors@Fingertip");
        setTitle("Join Our Doctors@Fingertip");

        db = DatabaseAccess.getInstance(this);//new Database(DoctorSignUpActivity.this);
        sp = getSharedPreferences("medical_pref", MODE_PRIVATE);
        dataprocessor = new SharedPrefHelper(DoctorSignUpActivity.this);
        edtbdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mcurrentDate = Calendar.getInstance();
                int mYear = mcurrentDate.get(Calendar.YEAR);
                int mMonth = mcurrentDate.get(Calendar.MONTH);
                int mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker = new DatePickerDialog(DoctorSignUpActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                        edtbdate.setText(selectedday + "/" + selectedmonth + "/" + selectedyear);
                        edtage.setText("" + PreferenceHelper.getAge(selectedyear, selectedmonth, selectedday));
                    }
                }, mYear, mMonth, mDay);
                mDatePicker.setTitle("Select date");
                mDatePicker.show();
            }
        });

        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtname.getText().toString().equals("")) {
                    Toast.makeText(DoctorSignUpActivity.this, "Name should not be Empty", Toast.LENGTH_LONG).show();
                } else if (edtemailid.getText().toString().equals("")) {
                    Toast.makeText(DoctorSignUpActivity.this, "Email Id should not be Empty", Toast.LENGTH_LONG).show();
                } else if (!edtemailid.getText().toString().contains("@")) {
                    Toast.makeText(DoctorSignUpActivity.this, "Email Id is invalid", Toast.LENGTH_LONG).show();
                } else if (edtbdate.getText().toString().equals("")) {
                    Toast.makeText(DoctorSignUpActivity.this, "Birth Date Id should not be Empty", Toast.LENGTH_LONG).show();
                } else if (edtage.getText().toString().equals("")) {
                    Toast.makeText(DoctorSignUpActivity.this, "Age should not be Empty", Toast.LENGTH_LONG).show();
                } else if (edtmobile.getText().toString().equals("")) {
                    Toast.makeText(DoctorSignUpActivity.this, "Mobile Number should not be Empty", Toast.LENGTH_LONG).show();
                } else if (!edtmobile.getText().toString().contains("+")) {
                    Toast.makeText(DoctorSignUpActivity.this, "Mobile Number must have country code", Toast.LENGTH_LONG).show();
                } else if (!edtqualification.getText().toString().equals("")) {
                    Toast.makeText(DoctorSignUpActivity.this, "Qualification Should not be Empty", Toast.LENGTH_LONG).show();
                }else if (!edtSpeciality.getText().toString().equals("")) {
                    Toast.makeText(DoctorSignUpActivity.this, "Speciality Should not be Empty", Toast.LENGTH_LONG).show();
                }
                else {
                    db.open();
                    if (db.getDoctorExits(edtemailid.getText().toString().trim())) {
                        Toast.makeText(DoctorSignUpActivity.this, "Email id already exist please try to login", Toast.LENGTH_SHORT).show();
                    } else {
                        DocModel d = new DocModel();
                        d.setDOCTOR_NAME(edtname.getText().toString().trim());
                        d.setDOCTOR_EMAILID(edtemailid.getText().toString().trim());
                        d.setDOCTOR_PASSWORD(edtpassword.getText().toString().trim());
                        d.setDOCTOR_QUALIFICATION(edtqualification.getText().toString().trim());
                        d.setDOCTOR_TOTALANS("0");
                        d.setDOCTOR_AGE(edtage.getText().toString().trim());
                        d.setDOCTOR_MOBILENUMBER(edtmobile.getText().toString().trim());
                        d.setDOCTOR_BIRTHDATE(edtbdate.getText().toString().trim());
                        d.setDOCTOR_TOTALREVIEWS("0");
                        db.AddDoctorData(d);

                    }
                    db.close();
                    dataprocessor.setString(PreferenceHelper.LoginEmailid, edtemailid.getText().toString().trim());
                    dataprocessor.setString(PreferenceHelper.LOGINTYPE, PreferenceHelper.TYPEDOC);

                    startActivity(new Intent(DoctorSignUpActivity.this, MainActivity.class));
                }


            }
        });
    }
}
