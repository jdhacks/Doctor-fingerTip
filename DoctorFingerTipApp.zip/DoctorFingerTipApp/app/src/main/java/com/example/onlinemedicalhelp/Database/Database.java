package com.example.onlinemedicalhelp.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

import com.example.onlinemedicalhelp.models.AnsModel;
import com.example.onlinemedicalhelp.models.DocModel;
import com.example.onlinemedicalhelp.models.PeopleModel;
import com.example.onlinemedicalhelp.models.QuestionModel;
import com.example.onlinemedicalhelp.models.ReviewModel;

import java.io.File;
import java.util.ArrayList;


public class Database extends SQLiteOpenHelper {
    SQLiteDatabase db;


    public final static String DB_NAME = "medical" + ".db";
    public final static int DB_VERSION = 3;

    public static final String PEOPLE_TBl = "people_table";

    public String PEOPLE_ID = "pid";
    public String PEOPLE_NAME = "p_name";
    public String PEOPLE_AGE = "p_age";
    public String PEOPLE_MOBILENUMBER = "p_mobile";
    public String PEOPLE_EMAILID = "p_emailid";
    public String PEOPLE_BIRTHDATE = "p_birthdate";
    public String PEOPLE_TOTALQUE = "p_tques";
    public String PEOPLE_TOTALREVIEWS = "p_treviews";
    public String PEOPLE_PASSWORD = "p_password";


    //CREATE QUERY
    public String CREATE_PEOPLE = "Create table " + PEOPLE_TBl + "(" + PEOPLE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + PEOPLE_NAME + " TEXT,"
            + PEOPLE_AGE + " TEXT,"
            + PEOPLE_EMAILID + " TEXT,"
            + PEOPLE_BIRTHDATE + " TEXT,"
            + PEOPLE_TOTALQUE + " TEXT,"
            + PEOPLE_TOTALREVIEWS + " TEXT,"
            + PEOPLE_PASSWORD + " TEXT,"
            + PEOPLE_MOBILENUMBER + " TEXT)";


    public static final String DOCTOR_TBl = "doctor_table";

    public String DOCTOR_ID = "did";
    public String DOCTOR_NAME = "d_name";
    public String DOCTOR_AGE = "d_age";
    public String DOCTOR_MOBILENUMBER = "d_mobile";
    public String DOCTOR_EMAILID = "d_emailid";
    public String DOCTOR_BIRTHDATE = "d_birthdate";
    public String DOCTOR_QUALIFICATION = "d_qualification";
    public String DOCTOR_TOTALANS = "d_tques";
    public String DOCTOR_TOTALREVIEWS = "d_treviews";
    public String DOCTOR_PASSWORD = "d_password";

    //CREATE QUERY
    public String CREATE_DOCTOR = "Create table " + DOCTOR_TBl + "(" + DOCTOR_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + DOCTOR_NAME + " TEXT,"
            + DOCTOR_AGE + " TEXT,"
            + DOCTOR_EMAILID + " TEXT,"
            + DOCTOR_BIRTHDATE + " TEXT,"
            + DOCTOR_QUALIFICATION + " TEXT,"
            + DOCTOR_TOTALANS + " TEXT,"
            + DOCTOR_TOTALREVIEWS + " TEXT,"
            + DOCTOR_PASSWORD + " TEXT,"
            + DOCTOR_MOBILENUMBER + " TEXT)";

    public static final String Ques_TBl = "question_table";

    public String Ques_ID = "qid";
    public String Ques_sub = "q_subject";
    public String Ques_date = "q_date";
    public String Ques_qaskid = "q_askid";
    public String Ques_que = "q_question";
    public String Ques_tanswers = "q_tans";
    public String Ques_treviews = "q_treviews";

    //CREATE QUERY
    public String CREATE_QUESTION = "Create table " + Ques_TBl + "(" + Ques_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + Ques_sub + " TEXT,"
            + Ques_date + " TEXT,"
            + Ques_qaskid + " TEXT,"
            + Ques_que + " TEXT,"
            + Ques_treviews + " TEXT,"
            + Ques_tanswers + " TEXT)";


    public static final String Ans_TBl = "answer_table";

    public String Ans_ID = "aid";
    public String Ans_sub = "a_subject";
    public String Ans_date = "a_date";
    public String Ans_quid = "a_quidt";
    public String Ans_qansid = "a_ans1id";
    public String Ans_que = "a_question";
    public String Ans_treviews = "a_treviews";



    //CREATE QUERY
    public String CREATE_ANSWER = "Create table " + Ans_TBl + "(" + Ans_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + Ans_sub + " TEXT,"
            + Ans_date + " TEXT,"
            + Ans_quid + " TEXT,"
            + Ans_qansid + " TEXT,"
            + Ans_que + " TEXT,"
            + Ans_treviews + " TEXT)";
    public static final String Review_TBl = "review_table";

    public String Review_ID = "rid";
    public String Review_sub = "r_subject";
    public String Review_date = "r_date";
    public String Review_quid = "r_quidt";
    public String Review_ansid = "r_ansid";
    public String Review_bid = "r_rebid";
    public String Review_que = "r_question";
    public String Review_ans = "r_ans";
    public String Review_rev = "r_rev";



    //CREATE QUERY
    public String CREATE_REVIEW = "Create table " + Review_TBl + "(" + Review_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + Review_sub + " TEXT,"
            + Review_date + " TEXT,"
            + Review_quid + " TEXT,"
            + Review_ansid + " TEXT,"
            + Review_ans + " TEXT,"
            + Review_que + " TEXT,"
            + Review_rev + " TEXT,"
            + Review_bid + " TEXT)";




    /* public Database(Context context) {
         super(context, Environment.getExternalStorageDirectory() + File.separator + DB_NAME, null, DB_VERSION);
     } */
    public Database(Context context) {//Environment.getExternalStorageDirectory() + File.separator +"Medical/"
        super(context,Environment.getExternalStorageDirectory() + File.separator + DB_NAME,null, DB_VERSION);
    }


    //GET WRITABLE
    public void open() {
        String DBPath = Environment.getExternalStorageDirectory() + File.separator +DB_NAME;
          File file = new File(DBPath);
          Log.e("TAG","database"+file.exists());
        if (file.exists() && !file.isDirectory())
        {

            file.setReadable(true);
            file.setWritable(true);
            db = SQLiteDatabase.openDatabase(DBPath,null,SQLiteDatabase.OPEN_READWRITE);

        }


        /*db = this.getWritableDatabase();*/
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_PEOPLE);
        db.execSQL(CREATE_DOCTOR);
        db.execSQL(CREATE_ANSWER);
        db.execSQL(CREATE_QUESTION);
        db.execSQL(CREATE_REVIEW);

    }

    public void AddPeopleData(PeopleModel fav) {

        ContentValues cv = new ContentValues();

        cv.put(PEOPLE_NAME, fav.getPEOPLE_NAME());
        cv.put(PEOPLE_AGE, fav.getPEOPLE_AGE());
        cv.put(PEOPLE_MOBILENUMBER, fav.getPEOPLE_MOBILENUMBER());
        cv.put(PEOPLE_EMAILID, fav.getPEOPLE_EMAILID());
        cv.put(PEOPLE_BIRTHDATE, fav.getPEOPLE_BIRTHDATE());
        cv.put(PEOPLE_TOTALQUE, fav.getPEOPLE_TOTALQUE());
        cv.put(PEOPLE_PASSWORD, fav.getPEOPLE_PASSWORD());
        cv.put(PEOPLE_TOTALREVIEWS, fav.getPEOPLE_TOTALREVIEWS());

        db.insert(PEOPLE_TBl, null, cv);

    }

    public ArrayList<PeopleModel> getAllPeopleData() {

        String quer = "select * from " + PEOPLE_TBl;

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<PeopleModel> all_data = new ArrayList<PeopleModel>();
        PeopleModel sp;

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

            sp = new PeopleModel();
            sp.setPEOPLE_ID(cursor.getInt(cursor.getColumnIndex(PEOPLE_ID)));
            sp.setPEOPLE_NAME(cursor.getString(cursor.getColumnIndex(PEOPLE_NAME)));
            sp.setPEOPLE_AGE(cursor.getString(cursor.getColumnIndex(PEOPLE_AGE)));
            sp.setPEOPLE_BIRTHDATE(cursor.getString(cursor.getColumnIndex(PEOPLE_BIRTHDATE)));
            sp.setPEOPLE_EMAILID(cursor.getString(cursor.getColumnIndex(PEOPLE_EMAILID)));
            sp.setPEOPLE_MOBILENUMBER(cursor.getString(cursor.getColumnIndex(PEOPLE_MOBILENUMBER)));
            sp.setPEOPLE_TOTALQUE(cursor.getString(cursor.getColumnIndex(PEOPLE_TOTALQUE)));
            sp.setPEOPLE_PASSWORD(cursor.getString(cursor.getColumnIndex(PEOPLE_PASSWORD)));
            sp.setPEOPLE_TOTALREVIEWS(cursor.getString(cursor.getColumnIndex(PEOPLE_TOTALREVIEWS)));

            all_data.add(sp);
        }
        return all_data;
    }

    public PeopleModel getthisPeopleData(String emailid) {

        String quer = "select * from " + PEOPLE_TBl+" WHERE  "+PEOPLE_EMAILID+" ='"+emailid +"'";

        Cursor cursor = db.rawQuery(quer, null);

        PeopleModel sp=null;

        if (cursor.getCount()>0) {

            sp = new PeopleModel();
            sp.setPEOPLE_ID(cursor.getInt(cursor.getColumnIndex(PEOPLE_ID)));
            sp.setPEOPLE_NAME(cursor.getString(cursor.getColumnIndex(PEOPLE_NAME)));
            sp.setPEOPLE_AGE(cursor.getString(cursor.getColumnIndex(PEOPLE_AGE)));
            sp.setPEOPLE_BIRTHDATE(cursor.getString(cursor.getColumnIndex(PEOPLE_BIRTHDATE)));
            sp.setPEOPLE_EMAILID(cursor.getString(cursor.getColumnIndex(PEOPLE_EMAILID)));
            sp.setPEOPLE_MOBILENUMBER(cursor.getString(cursor.getColumnIndex(PEOPLE_MOBILENUMBER)));
            sp.setPEOPLE_TOTALQUE(cursor.getString(cursor.getColumnIndex(PEOPLE_TOTALQUE)));
            sp.setPEOPLE_PASSWORD(cursor.getString(cursor.getColumnIndex(PEOPLE_PASSWORD)));
            sp.setPEOPLE_TOTALREVIEWS(cursor.getString(cursor.getColumnIndex(PEOPLE_TOTALREVIEWS)));


        }
        return sp;
    }

    public void DeleteDataPeople(String name, int id) {

        db.delete(PEOPLE_TBl, PEOPLE_ID + " =" + id + " AND " + PEOPLE_NAME + "='" + name + "'", null);

    }

    public boolean validRecordPeople(String name, int Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String q = "select * from " + PEOPLE_TBl + " where " + PEOPLE_NAME + " = '" + name + "'";
        Log.d("TAG", "is valid record arguments" + name + "...." + Dir);
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            Integer exid = cursor.getInt(cursor.getColumnIndex(PEOPLE_ID));
            String dir = cursor.getString(cursor.getColumnIndex(PEOPLE_NAME));
            Log.d("TAG", "Database data..." + exid + "...." + dir + "...is valid record arguments" + name + "...." + Dir);

            if (exid==Dir && dir.equalsIgnoreCase(dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name" + name);

                cursor.close();
                return true;
            } else {
                return false;
            }
        }
        cursor.close();
        return false;
    }

    public boolean isDownPeople(String name, int id) {
        db = getReadableDatabase();
        Cursor cursor;
        String q = "select * from " + PEOPLE_TBl + " where " + PEOPLE_NAME + " = " + name + "";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            int exid = cursor.getInt(cursor.getColumnIndex(PEOPLE_ID));
            String dir = cursor.getString(cursor.getColumnIndex(PEOPLE_NAME));
            if (exid==id && dir.equalsIgnoreCase(name)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name" + name);

                cursor.close();
                return true;
            } else {
                return false;
            }
        }
        cursor.close();
        return false;
    }

    /*public String getPathPeople(String id, String Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String path = null;
        String q = "select * from " + PEOPLE_TBl + " where " + PEOPLE_NAME + " = '" + id + "'";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            String exid = cursor.getString(cursor.getColumnIndex(PEOPLE_ID));
            String dir = cursor.getString(cursor.getColumnIndex(PEOPLE_NAME));
            if (exid.equalsIgnoreCase(id) && dir.equalsIgnoreCase(Dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name " + Dir);
                path = cursor.getString(cursor.getColumnIndex(DOWN_AUDIOLINK));
                cursor.close();
                return path;
            } else {
                return path;
            }
        }
        cursor.close();
        return path;
    }
*/
    public boolean isExistDownPeople() {
        String query = "select * from " + PEOPLE_TBl;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }
    public boolean getPeopleExits(String emailid) {
        String query = "select * from " + PEOPLE_TBl+" WHERE  "+PEOPLE_EMAILID+" ='"+emailid +"'";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }
    public boolean getPeopleLogin(String emailid, String password) {
        String query = "select * from " + PEOPLE_TBl+" WHERE  "+PEOPLE_EMAILID+" ='"+emailid +"' AND "+PEOPLE_PASSWORD+" ='"+password+"'";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }


    /*------------------------------------------------------------------*/

    public void AddDoctorData(DocModel fav) {

        ContentValues cv = new ContentValues();

        cv.put(DOCTOR_NAME, fav.getDOCTOR_NAME());
        cv.put(DOCTOR_AGE, fav.getDOCTOR_AGE());
        cv.put(DOCTOR_MOBILENUMBER, fav.getDOCTOR_MOBILENUMBER());
        cv.put(DOCTOR_EMAILID, fav.getDOCTOR_EMAILID());
        cv.put(DOCTOR_BIRTHDATE, fav.getDOCTOR_BIRTHDATE());
        cv.put(DOCTOR_QUALIFICATION, fav.getDOCTOR_QUALIFICATION());
        cv.put(DOCTOR_TOTALANS, fav.getDOCTOR_TOTALANS());
        cv.put(DOCTOR_PASSWORD, fav.getDOCTOR_PASSWORD());
        cv.put(DOCTOR_TOTALREVIEWS, fav.getDOCTOR_TOTALREVIEWS());

        db.insert(DOCTOR_TBl, null, cv);

    }

    public boolean getDoctorExits(String emailid) {
        String query = "select * from " + DOCTOR_TBl+" WHERE  "+DOCTOR_EMAILID+" ='"+emailid +"'";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }
    public ArrayList<DocModel> getAllDoctorData() {

        String quer = "select * from " + DOCTOR_TBl;

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<DocModel> all_data = new ArrayList<DocModel>();
        DocModel sp;

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

            sp = new DocModel();
            sp.setDOCTOR_ID(cursor.getInt(cursor.getColumnIndex(DOCTOR_ID)));
            sp.setDOCTOR_NAME(cursor.getString(cursor.getColumnIndex(DOCTOR_NAME)));
            sp.setDOCTOR_AGE(cursor.getString(cursor.getColumnIndex(DOCTOR_AGE)));
            sp.setDOCTOR_BIRTHDATE(cursor.getString(cursor.getColumnIndex(DOCTOR_BIRTHDATE)));
            sp.setDOCTOR_EMAILID(cursor.getString(cursor.getColumnIndex(DOCTOR_EMAILID)));
            sp.setDOCTOR_MOBILENUMBER(cursor.getString(cursor.getColumnIndex(DOCTOR_MOBILENUMBER)));
            sp.setDOCTOR_PASSWORD(cursor.getString(cursor.getColumnIndex(DOCTOR_PASSWORD)));
            sp.setDOCTOR_QUALIFICATION(cursor.getString(cursor.getColumnIndex(DOCTOR_QUALIFICATION)));
            sp.setDOCTOR_TOTALANS(cursor.getString(cursor.getColumnIndex(DOCTOR_TOTALANS)));
            sp.setDOCTOR_TOTALREVIEWS(cursor.getString(cursor.getColumnIndex(DOCTOR_TOTALREVIEWS)));

            all_data.add(sp);
        }
        return all_data;
    }

    public DocModel getThisDoctorData(String emailid) {

        String quer = "select * from " + DOCTOR_TBl+" WHERE  "+DOCTOR_EMAILID+" ='"+emailid +"'";

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<DocModel> all_data = new ArrayList<DocModel>();
        DocModel sp = null;

        if(cursor.getColumnCount()>0) {

            sp = new DocModel();
            sp.setDOCTOR_ID(cursor.getInt(cursor.getColumnIndex(DOCTOR_ID)));
            sp.setDOCTOR_NAME(cursor.getString(cursor.getColumnIndex(DOCTOR_NAME)));
            sp.setDOCTOR_AGE(cursor.getString(cursor.getColumnIndex(DOCTOR_AGE)));
            sp.setDOCTOR_BIRTHDATE(cursor.getString(cursor.getColumnIndex(DOCTOR_BIRTHDATE)));
            sp.setDOCTOR_EMAILID(cursor.getString(cursor.getColumnIndex(DOCTOR_EMAILID)));
            sp.setDOCTOR_MOBILENUMBER(cursor.getString(cursor.getColumnIndex(DOCTOR_MOBILENUMBER)));
            sp.setDOCTOR_PASSWORD(cursor.getString(cursor.getColumnIndex(DOCTOR_PASSWORD)));
            sp.setDOCTOR_QUALIFICATION(cursor.getString(cursor.getColumnIndex(DOCTOR_QUALIFICATION)));
            sp.setDOCTOR_TOTALANS(cursor.getString(cursor.getColumnIndex(DOCTOR_TOTALANS)));
            sp.setDOCTOR_TOTALREVIEWS(cursor.getString(cursor.getColumnIndex(DOCTOR_TOTALREVIEWS)));

           // all_data.add(sp);
        }
        return sp;
    }

    public void DeleteDataDoctor(String name, int id) {

        db.delete(DOCTOR_TBl, DOCTOR_ID + " =" + id + " AND " + DOCTOR_NAME + "='" + name + "'", null);

    }

    public boolean getDoctorLogin(String emailid, String password) {
        String query = "select * from " + DOCTOR_TBl+" WHERE  "+DOCTOR_EMAILID+" ='"+emailid +"' AND "+DOCTOR_PASSWORD+" ='"+password+"'";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }
    public boolean validRecordDoctor(String name, int Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String q = "select * from " + DOCTOR_TBl + " where " + DOCTOR_NAME + " = '" + name + "'";
        Log.d("TAG", "is valid record arguments" + name + "...." + Dir);
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            Integer exid = cursor.getInt(cursor.getColumnIndex(DOCTOR_ID));
            String dir = cursor.getString(cursor.getColumnIndex(DOCTOR_NAME));
            Log.d("TAG", "Database data..." + exid + "...." + dir + "...is valid record arguments" + name + "...." + Dir);

            if (exid==Dir && dir.equalsIgnoreCase(dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name" + name);

                cursor.close();
                return true;
            } else {
                return false;
            }
        }
        cursor.close();
        return false;
    }

    public boolean isDownDoctor(String name, int id) {
        db = getReadableDatabase();
        Cursor cursor;
        String q = "select * from " + DOCTOR_TBl + " where " + DOCTOR_NAME + " = " + name + "";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            int exid = cursor.getInt(cursor.getColumnIndex(DOCTOR_ID));
            String dir = cursor.getString(cursor.getColumnIndex(DOCTOR_NAME));
            if (exid==id && dir.equalsIgnoreCase(name)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name" + name);

                cursor.close();
                return true;
            } else {
                return false;
            }
        }
        cursor.close();
        return false;
    }

    /*public String getPath(String id, String Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String path = null;
        String q = "select * from " + DOCTOR_TBl + " where " + DOCTOR_NAME + " = '" + id + "'";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            String exid = cursor.getString(cursor.getColumnIndex(PEOPLE_ID));
            String dir = cursor.getString(cursor.getColumnIndex(PEOPLE_NAME));
            if (exid.equalsIgnoreCase(id) && dir.equalsIgnoreCase(Dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name " + Dir);
                path = cursor.getString(cursor.getColumnIndex(DOWN_AUDIOLINK));
                cursor.close();
                return path;
            } else {
                return path;
            }
        }
        cursor.close();
        return path;
    }
*/
    public boolean isExistDownDoctor() {
        String query = "select * from " + DOCTOR_TBl;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }

    /*------------------------------------------------------------------*/

    public void AddAnswerData(AnsModel fav) {

        ContentValues cv = new ContentValues();

        cv.put(Ans_date, fav.getAns_date());
        cv.put(Ans_qansid, fav.getAns_qansid());
        cv.put(Ans_que, fav.getAns_que());
        cv.put(Ans_quid, fav.getAns_quid());
        cv.put(Ans_sub, fav.getAns_sub());
        cv.put(Ans_treviews, fav.getAns_treviews());

        db.insert(Ans_TBl, null, cv);

    }

    public ArrayList<AnsModel> getAllAnswerData() {

        String quer = "select * from " + Ans_TBl;

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<AnsModel> all_data = new ArrayList<AnsModel>();
        AnsModel sp;

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

            sp = new AnsModel();
            sp.setAns_ID(cursor.getInt(cursor.getColumnIndex(Ans_ID)));
            sp.setAns_qansid(cursor.getString(cursor.getColumnIndex(Ans_qansid)));
            sp.setAns_date(cursor.getString(cursor.getColumnIndex(Ans_date)));
            sp.setAns_que(cursor.getString(cursor.getColumnIndex(Ans_que)));
            sp.setAns_quid(cursor.getString(cursor.getColumnIndex(Ans_quid)));
            sp.setAns_sub(cursor.getString(cursor.getColumnIndex(Ans_sub)));
            sp.setAns_treviews(cursor.getString(cursor.getColumnIndex(Ans_treviews)));

            all_data.add(sp);
        }
        return all_data;
    }

    public void DeleteDataAnswer(String name, int id) {

        db.delete(Ans_TBl, Ans_ID + " =" + id , null);

    }

    /*public String getPath(String id, String Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String path = null;
        String q = "select * from " + DOCTOR_TBl + " where " + DOCTOR_NAME + " = '" + id + "'";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            String exid = cursor.getString(cursor.getColumnIndex(PEOPLE_ID));
            String dir = cursor.getString(cursor.getColumnIndex(PEOPLE_NAME));
            if (exid.equalsIgnoreCase(id) && dir.equalsIgnoreCase(Dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name " + Dir);
                path = cursor.getString(cursor.getColumnIndex(DOWN_AUDIOLINK));
                cursor.close();
                return path;
            } else {
                return path;
            }
        }
        cursor.close();
        return path;
    }
*/
    public boolean isExistDownAnswer() {
        String query = "select * from " + Ans_TBl;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }


    /*------------------------------------------------------------------*/

    public void AddQuestionData(QuestionModel fav) {

        ContentValues cv = new ContentValues();

        cv.put(Ques_date, fav.getQues_date());
        cv.put(Ques_qaskid, fav.getQues_qaskid());
        cv.put(Ques_que, fav.getQues_que());
        cv.put(Ques_tanswers, fav.getQues_tanswers());
        cv.put(Ques_sub, fav.getQues_sub());
        cv.put(Ques_treviews, fav.getQues_treviews());

        db.insert(Ques_TBl, null, cv);

    }

    public ArrayList<QuestionModel> getAllQuestionData() {

        String quer = "select * from " + Ques_TBl;

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<QuestionModel> all_data = new ArrayList<QuestionModel>();
        QuestionModel sp;

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

            sp = new QuestionModel();
            sp.setQues_ID(cursor.getInt(cursor.getColumnIndex(Ques_ID)));
            sp.setQues_tanswers(cursor.getString(cursor.getColumnIndex(Ques_tanswers)));
            sp.setQues_date(cursor.getString(cursor.getColumnIndex(Ques_date)));
            sp.setQues_que(cursor.getString(cursor.getColumnIndex(Ques_que)));
            sp.setQues_qaskid(cursor.getString(cursor.getColumnIndex(Ques_qaskid)));
            sp.setQues_sub(cursor.getString(cursor.getColumnIndex(Ques_sub)));
            sp.setQues_treviews(cursor.getString(cursor.getColumnIndex(Ques_treviews)));

            all_data.add(sp);
        }
        return all_data;
    }

    public void UpDateQuestionData(QuestionModel qm)
    {
        ContentValues cv = new ContentValues();
        cv.put(Ques_date, qm.getQues_date());
        cv.put(Ques_qaskid, qm.getQues_qaskid());
        cv.put(Ques_que, qm.getQues_que());
        cv.put(Ques_tanswers, qm.getQues_tanswers());
        cv.put(Ques_sub, qm.getQues_sub());
        cv.put(Ques_treviews, qm.getQues_treviews());


        db.update(Ques_TBl, cv, Ques_ID+"="+qm.getQues_ID()+" AND  "+Ques_sub+"", null);
    }
    public void DeleteDataQuestion(String name, int id) {

        db.delete(Ques_TBl, Ques_ID + " =" + id , null);

    }

    /*public String getPath(String id, String Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String path = null;
        String q = "select * from " + DOCTOR_TBl + " where " + DOCTOR_NAME + " = '" + id + "'";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            String exid = cursor.getString(cursor.getColumnIndex(PEOPLE_ID));
            String dir = cursor.getString(cursor.getColumnIndex(PEOPLE_NAME));
            if (exid.equalsIgnoreCase(id) && dir.equalsIgnoreCase(Dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name " + Dir);
                path = cursor.getString(cursor.getColumnIndex(DOWN_AUDIOLINK));
                cursor.close();
                return path;
            } else {
                return path;
            }
        }
        cursor.close();
        return path;
    }
*/
    public boolean isExistDownQuestion() {
        String query = "select * from " + Ques_TBl;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }

    /*------------------------------------------------------------------*/

    public void AddReviewData(ReviewModel fav) {

        ContentValues cv = new ContentValues();

        cv.put(Review_date, fav.getReview_date());
        cv.put(Review_ans, fav.getReview_ans());
        cv.put(Review_que, fav.getReview_que());
        cv.put(Review_ansid, fav.getReview_ansid());
        cv.put(Review_quid, fav.getReview_quid());
        cv.put(Review_bid, fav.getReview_bid());
        cv.put(Review_sub, fav.getReview_sub());
        cv.put(Review_rev, fav.getReview_rev());
        db.insert(Review_TBl, null, cv);

    }

    public ArrayList<ReviewModel> getAllReviewData() {

        String quer = "select * from " + Review_TBl;

        Cursor cursor = db.rawQuery(quer, null);

        ArrayList<ReviewModel> all_data = new ArrayList<ReviewModel>();
        ReviewModel sp;

        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {

            sp = new ReviewModel();
            sp.setReview_ID(cursor.getInt(cursor.getColumnIndex(Review_ID)));
            sp.setReview_ans(cursor.getString(cursor.getColumnIndex(Review_ans)));
            sp.setReview_date(cursor.getString(cursor.getColumnIndex(Review_date)));
            sp.setReview_que(cursor.getString(cursor.getColumnIndex(Review_que)));
            sp.setReview_ansid(cursor.getString(cursor.getColumnIndex(Review_ansid)));
            sp.setReview_sub(cursor.getString(cursor.getColumnIndex(Review_sub)));
            sp.setReview_rev(cursor.getString(cursor.getColumnIndex(Review_rev)));
            sp.setReview_quid(cursor.getString(cursor.getColumnIndex(Review_quid)));
            sp.setReview_bid(cursor.getString(cursor.getColumnIndex(Review_bid)));

            all_data.add(sp);
        }
        return all_data;
    }

    public void DeleteDataReview(String name, int id) {

        db.delete(Review_TBl, Review_ID + " =" + id , null);

    }

    /*public String getPath(String id, String Dir) {
        db = getReadableDatabase();
        Cursor cursor;
        String path = null;
        String q = "select * from " + DOCTOR_TBl + " where " + DOCTOR_NAME + " = '" + id + "'";
        cursor = db.rawQuery(q, null);
        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            String exid = cursor.getString(cursor.getColumnIndex(PEOPLE_ID));
            String dir = cursor.getString(cursor.getColumnIndex(PEOPLE_NAME));
            if (exid.equalsIgnoreCase(id) && dir.equalsIgnoreCase(Dir)) {
                Log.d("TAG", "DOWNNAME" + exid + "passing name " + Dir);
                path = cursor.getString(cursor.getColumnIndex(DOWN_AUDIOLINK));
                cursor.close();
                return path;
            } else {
                return path;
            }
        }
        cursor.close();
        return path;
    }
*/
    public boolean isExistDownReview() {
        String query = "select * from " + Review_TBl;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        }
        cursor.close();
        return false;

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }

}