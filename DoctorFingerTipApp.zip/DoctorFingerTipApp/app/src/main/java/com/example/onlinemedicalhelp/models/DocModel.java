package com.example.onlinemedicalhelp.models;

public class DocModel {

    public Integer DOCTOR_ID ;
    public String DOCTOR_NAME;
    public String DOCTOR_AGE ;
    public String DOCTOR_MOBILENUMBER ;
    public String DOCTOR_EMAILID;
    public String DOCTOR_BIRTHDATE ;
    public String DOCTOR_QUALIFICATION;
    public String DOCTOR_TOTALANS ;

    public String getDOCTOR_PASSWORD() {
        return DOCTOR_PASSWORD;
    }

    public void setDOCTOR_PASSWORD(String DOCTOR_PASSWORD) {
        this.DOCTOR_PASSWORD = DOCTOR_PASSWORD;
    }

    public String DOCTOR_PASSWORD ;
    public String DOCTOR_TOTALREVIEWS ;

    public Integer getDOCTOR_ID() {
        return DOCTOR_ID;
    }

    public void setDOCTOR_ID(Integer DOCTOR_ID) {
        this.DOCTOR_ID = DOCTOR_ID;
    }

    public String getDOCTOR_NAME() {
        return DOCTOR_NAME;
    }

    public void setDOCTOR_NAME(String DOCTOR_NAME) {
        this.DOCTOR_NAME = DOCTOR_NAME;
    }

    public String getDOCTOR_AGE() {
        return DOCTOR_AGE;
    }

    public void setDOCTOR_AGE(String DOCTOR_AGE) {
        this.DOCTOR_AGE = DOCTOR_AGE;
    }

    public String getDOCTOR_MOBILENUMBER() {
        return DOCTOR_MOBILENUMBER;
    }

    public void setDOCTOR_MOBILENUMBER(String DOCTOR_MOBILENUMBER) {
        this.DOCTOR_MOBILENUMBER = DOCTOR_MOBILENUMBER;
    }

    public String getDOCTOR_EMAILID() {
        return DOCTOR_EMAILID;
    }

    public void setDOCTOR_EMAILID(String DOCTOR_EMAILID) {
        this.DOCTOR_EMAILID = DOCTOR_EMAILID;
    }

    public String getDOCTOR_BIRTHDATE() {
        return DOCTOR_BIRTHDATE;
    }

    public void setDOCTOR_BIRTHDATE(String DOCTOR_BIRTHDATE) {
        this.DOCTOR_BIRTHDATE = DOCTOR_BIRTHDATE;
    }

    public String getDOCTOR_QUALIFICATION() {
        return DOCTOR_QUALIFICATION;
    }

    public void setDOCTOR_QUALIFICATION(String DOCTOR_QUALIFICATION) {
        this.DOCTOR_QUALIFICATION = DOCTOR_QUALIFICATION;
    }

    public String getDOCTOR_TOTALANS() {
        return DOCTOR_TOTALANS;
    }

    public void setDOCTOR_TOTALANS(String DOCTOR_TOTALANS) {
        this.DOCTOR_TOTALANS = DOCTOR_TOTALANS;
    }

    public String getDOCTOR_TOTALREVIEWS() {
        return DOCTOR_TOTALREVIEWS;
    }

    public void setDOCTOR_TOTALREVIEWS(String DOCTOR_TOTALREVIEWS) {
        this.DOCTOR_TOTALREVIEWS = DOCTOR_TOTALREVIEWS;
    }
}
