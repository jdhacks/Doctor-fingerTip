package com.example.onlinemedicalhelp.models;

public class AnsModel {

    public Integer Ans_ID ;
    public String Ans_sub;
    public String Ans_date;
    public String Ans_quid;
    public String Ans_qansid;
    public String Ans_que;
    public String Ans_treviews;

    public Integer getAns_ID() {
        return Ans_ID;
    }

    public void setAns_ID(Integer ans_ID) {
        Ans_ID = ans_ID;
    }

    public String getAns_sub() {
        return Ans_sub;
    }

    public void setAns_sub(String ans_sub) {
        Ans_sub = ans_sub;
    }

    public String getAns_date() {
        return Ans_date;
    }

    public void setAns_date(String ans_date) {
        Ans_date = ans_date;
    }

    public String getAns_quid() {
        return Ans_quid;
    }

    public void setAns_quid(String ans_quid) {
        Ans_quid = ans_quid;
    }

    public String getAns_qansid() {
        return Ans_qansid;
    }

    public void setAns_qansid(String ans_qansid) {
        Ans_qansid = ans_qansid;
    }

    public String getAns_que() {
        return Ans_que;
    }

    public void setAns_que(String ans_que) {
        Ans_que = ans_que;
    }

    public String getAns_treviews() {
        return Ans_treviews;
    }

    public void setAns_treviews(String ans_treviews) {
        Ans_treviews = ans_treviews;
    }
}
