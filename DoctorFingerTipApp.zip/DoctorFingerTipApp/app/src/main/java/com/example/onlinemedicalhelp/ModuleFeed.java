package com.example.onlinemedicalhelp;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.onlinemedicalhelp.Database.DatabaseAccess;
import com.example.onlinemedicalhelp.models.AnsModel;
import com.example.onlinemedicalhelp.models.DocModel;
import com.example.onlinemedicalhelp.models.FAnsModel;
import com.example.onlinemedicalhelp.models.FeedModel;
import com.example.onlinemedicalhelp.models.PeopleModel;
import com.example.onlinemedicalhelp.models.QuestionModel;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

public class ModuleFeed extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.recfeed)
    RecyclerView recfeed;

    DatabaseAccess db;

    FeedAdapter feedadapter;

    ArrayList<FeedModel> feedModels = new ArrayList<>();
    ArrayList<QuestionModel> questionModels = new ArrayList<>();

    ArrayList<AnsModel> ansModels = new ArrayList<>();
    ArrayList<FAnsModel> fansmodels;

    //    ArrayList<ReviewModel> reviewModels=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module_feed);
        ButterKnife.bind(this);

        toolbar.setTitle("Questions & Answers");

        db = DatabaseAccess.getInstance(ModuleFeed.this);


        db.open();
        questionModels.addAll(db.getAllQuestionData());
        db.close();
        LinearLayoutManager llm = new LinearLayoutManager(ModuleFeed.this);
        llm.setOrientation(RecyclerView.VERTICAL);
        recfeed.setLayoutManager(llm);
        recfeed.setHasFixedSize(true);
        recfeed.setNestedScrollingEnabled(false);
        feedadapter = new FeedAdapter(ModuleFeed.this, feedModels);
        recfeed.setAdapter(feedadapter);
        for (int i = 0; i < questionModels.size(); i++) {
            db.open();

            QuestionModel qm = new QuestionModel();

            qm = questionModels.get(i);
            FeedModel fm = new FeedModel();
            fm.setQid(String.valueOf(qm.getQues_ID()));
            fm.setQuestion(qm.getQues_que());
            fm.setQdate(qm.getQues_date());
            PeopleModel pm = new PeopleModel();
            pm = db.getPeopleById(Integer.parseInt(qm.getQues_qaskid().replace("p", "")));
            fm.setQby(pm.getPEOPLE_NAME());
            ansModels = new ArrayList<>();
            ansModels.addAll(db.getAllAnswerToQuestion(String.valueOf(qm.getQues_ID())));
            fansmodels = new ArrayList<>();

            for (int j = 0; j < ansModels.size(); j++) {


                FAnsModel fam = new FAnsModel();
                DocModel dm = new DocModel();
                dm = db.getThisDoctorByid(Integer.parseInt(ansModels.get(j).getAns_quid().replace("d", "")));
                /*ansby.add(dm.getDOCTOR_NAME());*/
                fam.setAnsby(dm.getDOCTOR_NAME());
                fam.setAnswer(ansModels.get(j).getAns_sub());
                fam.setAnswerDate(ansModels.get(j).getAns_date());
                fam.setAnswerid(String.valueOf(ansModels.get(j).getAns_ID()));

                fansmodels.add(fam);

            }
            fm.setListanss(fansmodels);
            feedModels.add(fm);
            db.close();

        }


        if (feedModels.size() > 0) {
            feedadapter.notifyDataSetChanged();
        }
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater();
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return false;
    }

    public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.FeedView> {
        Context context;
        ArrayList<FeedModel> feedlist;

        public FeedAdapter(Context context, ArrayList<FeedModel> feedlist) {
            this.context = context;
            this.feedlist = feedlist;
        }

        @NonNull
        @Override
        public FeedView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.layqueans, parent, false);
            FeedView vh = new FeedView(view);
            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull FeedView holder, int position) {
            final FeedModel fm = feedlist.get(position);
            holder.txtquestion.setText(fm.getQuestion());
            holder.byquestion.setText("By: "+fm.getQby());
            holder.onquedate.setText("On: "+fm.getQdate());
                    LinearLayoutManager llm = new LinearLayoutManager(context);
            llm.setOrientation(RecyclerView.VERTICAL);

            RevAnsAdapter revAnsAdapter = new RevAnsAdapter(context, fm.getListanss());
            holder.recanswer.setLayoutManager(llm);
            holder.recanswer.setAdapter(revAnsAdapter);
            holder.recanswer.setHasFixedSize(true);
            holder.recanswer.setNestedScrollingEnabled(false);

            if (fm.getListanss().size() > 0) {
                revAnsAdapter.notifyDataSetChanged();
            }

        }

        @Override
        public int getItemCount() {
            return feedlist.size();
        }


        public class FeedView extends RecyclerView.ViewHolder {
            @BindView(R.id.lblquestion)
            TextView lblquestion;
            @BindView(R.id.onquedate)
            TextView onquedate;
            @BindView(R.id.txtquestion)
            TextView txtquestion;
            @BindView(R.id.byquestion)
            TextView byquestion;
            @BindView(R.id.lblanswers)
            TextView lblanswers;
            @BindView(R.id.recanswer)
            RecyclerView recanswer;

            public FeedView(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);

            }
        }


    }

    public class RevAnsAdapter extends RecyclerView.Adapter<RevAnsAdapter.RevAnsView> {
        Context context;
        ArrayList<FAnsModel> feedlist;

        public RevAnsAdapter(Context context, ArrayList<FAnsModel> feedlist) {
            this.context = context;
            this.feedlist = feedlist;
        }

        @NonNull
        @Override
        public RevAnsView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.layans, parent, false);
            RevAnsView vh = new RevAnsView(view);
            return vh;
        }

        @Override
        public void onBindViewHolder(@NonNull RevAnsView holder, int position) {
            FAnsModel fam= feedlist.get(position);
            holder.txtanswer.setText(fam.getAnswer());
            holder.byanswer.setText("By: "+fam.getAnsby());
            holder.onansdate.setText("On: "+fam.getAnswerDate());

        }

        @Override
        public int getItemCount() {
            return feedlist.size();
        }


        public class RevAnsView extends RecyclerView.ViewHolder {
            @BindView(R.id.onansdate)
            TextView onansdate;
            @BindView(R.id.txtanswer)
            TextView txtanswer;
            @BindView(R.id.byanswer)
            TextView byanswer;

            public RevAnsView(@NonNull View itemView) {
                super(itemView);
                ButterKnife.bind(this, itemView);

            }
        }


    }

}
