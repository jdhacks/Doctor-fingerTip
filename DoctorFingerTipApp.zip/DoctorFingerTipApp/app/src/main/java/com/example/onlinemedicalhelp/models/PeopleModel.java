package com.example.onlinemedicalhelp.models;

public class PeopleModel {

    public Integer PEOPLE_ID;
    public String PEOPLE_NAME;
    public String PEOPLE_AGE ;
    public String PEOPLE_MOBILENUMBER ;
    public String PEOPLE_EMAILID;
    public String PEOPLE_BIRTHDATE ;
    public String PEOPLE_TOTALQUE ;
    public String PEOPLE_TOTALREVIEWS;
    public String PEOPLE_PASSWORD;

    public Integer getPEOPLE_ID() {
        return PEOPLE_ID;
    }

    public void setPEOPLE_ID(Integer PEOPLE_ID) {
        this.PEOPLE_ID = PEOPLE_ID;
    }

    public String getPEOPLE_NAME() {
        return PEOPLE_NAME;
    }

    public void setPEOPLE_NAME(String PEOPLE_NAME) {
        this.PEOPLE_NAME = PEOPLE_NAME;
    }

    public String getPEOPLE_AGE() {
        return PEOPLE_AGE;
    }

    public void setPEOPLE_AGE(String PEOPLE_AGE) {
        this.PEOPLE_AGE = PEOPLE_AGE;
    }

    public String getPEOPLE_MOBILENUMBER() {
        return PEOPLE_MOBILENUMBER;
    }

    public void setPEOPLE_MOBILENUMBER(String PEOPLE_MOBILENUMBER) {
        this.PEOPLE_MOBILENUMBER = PEOPLE_MOBILENUMBER;
    }

    public String getPEOPLE_EMAILID() {
        return PEOPLE_EMAILID;
    }

    public void setPEOPLE_EMAILID(String PEOPLE_EMAILID) {
        this.PEOPLE_EMAILID = PEOPLE_EMAILID;
    }

    public String getPEOPLE_BIRTHDATE() {
        return PEOPLE_BIRTHDATE;
    }

    public void setPEOPLE_BIRTHDATE(String PEOPLE_BIRTHDATE) {
        this.PEOPLE_BIRTHDATE = PEOPLE_BIRTHDATE;
    }

    public String getPEOPLE_TOTALQUE() {
        return PEOPLE_TOTALQUE;
    }

    public void setPEOPLE_TOTALQUE(String PEOPLE_TOTALQUE) {
        this.PEOPLE_TOTALQUE = PEOPLE_TOTALQUE;
    }

    public String getPEOPLE_TOTALREVIEWS() {
        return PEOPLE_TOTALREVIEWS;
    }

    public void setPEOPLE_TOTALREVIEWS(String PEOPLE_TOTALREVIEWS) {
        this.PEOPLE_TOTALREVIEWS = PEOPLE_TOTALREVIEWS;
    }

    public String getPEOPLE_PASSWORD() {
        return PEOPLE_PASSWORD;
    }

    public void setPEOPLE_PASSWORD(String PEOPLE_PASSWORD) {
        this.PEOPLE_PASSWORD = PEOPLE_PASSWORD;
    }
}
