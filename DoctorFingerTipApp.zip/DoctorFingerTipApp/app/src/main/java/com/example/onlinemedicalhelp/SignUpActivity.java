package com.example.onlinemedicalhelp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.onlinemedicalhelp.Database.Database;
import com.example.onlinemedicalhelp.Database.DatabaseAccess;
import com.example.onlinemedicalhelp.helper.PreferenceHelper;
import com.example.onlinemedicalhelp.helper.SharedPrefHelper;
import com.example.onlinemedicalhelp.models.DocModel;
import com.example.onlinemedicalhelp.models.PeopleModel;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import butterknife.BindView;
import butterknife.ButterKnife;

public class SignUpActivity extends AppCompatActivity {


    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.lblemailid)
    TextView lblemailid;
    @BindView(R.id.edtemailid)
    EditText edtemailid;
    @BindView(R.id.lblname)
    TextView lblname;
    @BindView(R.id.edtname)
    EditText edtname;
    @BindView(R.id.lblmobile)
    TextView lblmobile;
    @BindView(R.id.edtmobile)
    EditText edtmobile;
    @BindView(R.id.lblbdate)
    TextView lblbdate;
    @BindView(R.id.edtbdate)
    TextView edtbdate;
    @BindView(R.id.lblage)
    TextView lblage;
    @BindView(R.id.edtage)
    TextView edtage;
    @BindView(R.id.lblpass)
    TextView lblpass;
    @BindView(R.id.edtpassword)
    EditText edtpassword;
    @BindView(R.id.btnsignup)
    Button btnsignup;

    public SharedPreferences sp;
    public SharedPrefHelper dataprocessor;

    DatabaseAccess db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        ButterKnife.bind(this);

        toolbar.setTitle("Join Our Patients@Fingertip");
        db=DatabaseAccess.getInstance(this);//new Database(SignUpActivity.this);
        sp = getSharedPreferences("medical_pref", MODE_PRIVATE);
        dataprocessor = new SharedPrefHelper(SignUpActivity.this);

        edtbdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mcurrentDate=Calendar.getInstance();
                int mYear=mcurrentDate.get(Calendar.YEAR);
                int mMonth=mcurrentDate.get(Calendar.MONTH);
                int mDay=mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker=new DatePickerDialog(SignUpActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                    edtbdate.setText(selectedday+"/"+selectedmonth+"/"+selectedyear);
                    edtage.setText(PreferenceHelper.getAge(selectedyear,selectedmonth,selectedday));
                    }
                },mYear, mMonth, mDay);
                mDatePicker.setTitle("Select date");
                mDatePicker.show();
            }
        });
        if (checkAndRequestPermissions()) {

            db.open();
           /* if (!db.isExistDownPeople()) {

                PeopleModel p = new PeopleModel();
                p.setPEOPLE_NAME("Mr. abc");
                p.setPEOPLE_TOTALREVIEWS("0");
                p.setPEOPLE_EMAILID("abc@gmail.com");
                p.setPEOPLE_TOTALQUE("0");
                p.setPEOPLE_MOBILENUMBER("+911212121212");
                p.setPEOPLE_BIRTHDATE("03/01/1995");
                p.setPEOPLE_AGE("25");
                p.setPEOPLE_PASSWORD("abc@people");
                db.AddPeopleData(p);
            }
            if (!db.isExistDownDoctor()) {
                DocModel d = new DocModel();
                d.setDOCTOR_NAME("Dr. xyz");
                d.setDOCTOR_TOTALREVIEWS("0");
                d.setDOCTOR_EMAILID("xyz@gmail.com");
                d.setDOCTOR_TOTALANS("0");
                d.setDOCTOR_QUALIFICATION("MBBS");
                d.setDOCTOR_MOBILENUMBER("+911212121212");
                d.setDOCTOR_BIRTHDATE("09/05/1980");
                d.setDOCTOR_AGE("40");
                d.setDOCTOR_PASSWORD("xyz@doctor");
                db.AddDoctorData(d);

            }*/
            db.close();

        } else {
            Toast.makeText(this, "Please Grant These Permissions", Toast.LENGTH_SHORT).show();
        }
        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtname.getText().toString().equals("")) {
                    Toast.makeText(SignUpActivity.this,"Name should not be Empty",Toast.LENGTH_LONG).show();
                }else if(edtemailid.getText().toString().equals("")) {
                    Toast.makeText(SignUpActivity.this,"Email Id should not be Empty",Toast.LENGTH_LONG).show();
                }else if(!edtemailid.getText().toString().contains("@")) {
                    Toast.makeText(SignUpActivity.this,"Email Id is invalid",Toast.LENGTH_LONG).show();
                }else if(edtbdate.getText().toString().equals("")) {
                    Toast.makeText(SignUpActivity.this,"Birth Date Id should not be Empty",Toast.LENGTH_LONG).show();
                }else if(edtage.getText().toString().equals("")) {
                    Toast.makeText(SignUpActivity.this,"Age should not be Empty",Toast.LENGTH_LONG).show();
                }else if(edtmobile.getText().toString().equals("")) {
                    Toast.makeText(SignUpActivity.this,"Mobile Number should not be Empty",Toast.LENGTH_LONG).show();
                }else if(!edtmobile.getText().toString().contains("+")) {
                    Toast.makeText(SignUpActivity.this,"Mobile Number must have country code",Toast.LENGTH_LONG).show();
                }else{
                    db.open();
                    if(db.getPeopleExits(edtemailid.getText().toString().trim()))
                    {
                        Toast.makeText(SignUpActivity.this, "Email id already exist please try to login", Toast.LENGTH_SHORT).show();
                    }else{
                        PeopleModel d=new PeopleModel();
                        d.setPEOPLE_NAME(edtname.getText().toString().trim());
                        d.setPEOPLE_EMAILID(edtemailid.getText().toString().trim());
                        d.setPEOPLE_PASSWORD(edtpassword.getText().toString().trim());
                        d.setPEOPLE_TOTALQUE("0");
                        d.setPEOPLE_AGE(edtage.getText().toString().trim());
                        d.setPEOPLE_MOBILENUMBER(edtmobile.getText().toString().trim());
                        d.setPEOPLE_BIRTHDATE(edtbdate.getText().toString().trim());
                        d.setPEOPLE_TOTALREVIEWS("0");
                        db.AddPeopleData(d);

                    }
                    db.close();
                    dataprocessor.setString(PreferenceHelper.LoginEmailid,edtemailid.getText().toString().trim());
                    dataprocessor.setString(PreferenceHelper.LOGINTYPE, PreferenceHelper.TYPEPEOPLE);

                    startActivity(new Intent(SignUpActivity.this,MainActivity.class));
                }


            }
        });

    }
    private boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE");
        int locationPermission = ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE");

        List<String> listPermissionsNeeded = new ArrayList();
        if (locationPermission != 0) {
            listPermissionsNeeded.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (permissionSendMessage != 0) {
            listPermissionsNeeded.add("android.permission.READ_EXTERNAL_STORAGE");
        }

        if (listPermissionsNeeded.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
        return false;
    }
}
