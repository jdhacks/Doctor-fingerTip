package com.example.onlinemedicalhelp.helper;

import android.content.Context;
import android.content.SharedPreferences;

import java.lang.reflect.Type;
import java.util.ArrayList;



public class SharedPrefHelper {
    Context context;
    public final static String PREFS_NAME = "medical_prefs";

    public SharedPrefHelper(Context context){
        this.context = context;
    }

    public void setCondi(String key, Boolean value) {

        SharedPreferences sharedPref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(key,value);
        editor.apply();
    }
    public Boolean getCondi(String key) {

        SharedPreferences sharedPref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return sharedPref.getBoolean(key,false);
    }

    public void setString(String key, String value) {

        SharedPreferences sharedPref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(key,value);
        editor.apply();
    }
    public String getString(String key) {

        SharedPreferences sharedPref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return sharedPref.getString(key,"");
    }
}
