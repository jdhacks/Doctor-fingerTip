package com.example.onlinemedicalhelp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.onlinemedicalhelp.Database.Database;
import com.example.onlinemedicalhelp.Database.DatabaseAccess;
import com.example.onlinemedicalhelp.helper.SharedPrefHelper;
import com.example.onlinemedicalhelp.models.AnsModel;
import com.example.onlinemedicalhelp.models.QuestionModel;
import com.example.onlinemedicalhelp.models.ReviewModel;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import butterknife.BindView;
import butterknife.ButterKnife;

import static com.example.onlinemedicalhelp.helper.PreferenceHelper.LOGINTYPE;
import static com.example.onlinemedicalhelp.helper.PreferenceHelper.TYPEDOC;

public class MainActivity extends AppCompatActivity {

    public static DatabaseAccess db;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.modulePeople)
    LinearLayout modulePeople;
    @BindView(R.id.moduleDoctors)
    LinearLayout moduleDoctors;

    SharedPrefHelper dataprocessor;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        sp= getSharedPreferences("medical_prefs",MODE_PRIVATE);
        dataprocessor= new SharedPrefHelper(MainActivity.this);

        if(sp.contains(LOGINTYPE))
        {
            if(dataprocessor.getString(LOGINTYPE).equalsIgnoreCase(TYPEDOC))
            {
                modulePeople.setVisibility(View.GONE);
            }else{
                moduleDoctors.setVisibility(View.GONE);
            }
        }

        checkAndRequestPermissions();
        db = DatabaseAccess.getInstance(this);//new Database(MainActivity.this);
        db.open();
       /* if (!db.isExistDownAnswer()) {

            AnsModel p = new AnsModel();
            p.setAns_sub("For Fever you can do below things : \n" +
                    "Sit in a bath of lukewarm water, which will feel cool when you have a fever. (Cold water will actually cause your body to warm up instead of cool down.)\n" +
                    "Give yourself a sponge bath with lukewarm water.\n" +
                    "Wear light pajamas or clothing.\n" +
                    "Try to avoid using too many extra blankets when you have chills.\n" +
                    "Drink plenty of cool or room-temperature water.\n" +
                    "Eat popsicles.\n" +
                    "Use a fan to keep air circulating.");
            p.setAns_que("How to Overcome Fever without Medication??");
            p.setAns_treviews("0");
            p.setAns_quid("1");
            p.setAns_qansid("1");
            p.setAns_date("17/3/2020");

            db.AddAnswerData(p);
        }
        if (!db.isExistDownQuestion()) {

            QuestionModel p = new QuestionModel();
            p.setQues_qaskid("1");
            p.setQues_que("How to Overcome Fever without Medication??");
            p.setQues_sub("Healing And Solutions");
            p.setQues_tanswers("1");
            p.setQues_date("17/3/2020");
            p.setQues_treviews("1");

            db.AddQuestionData(p);
        }
        if (!db.isExistDownReview()) {

            ReviewModel p = new ReviewModel();
            p.setReview_que("How to Overcome Fever without Medication??");
            p.setReview_quid("1");
            p.setReview_ansid("0");
            p.setReview_date("17/3/2020");
            p.setReview_ans("null");
            p.setReview_sub("Healing And Solutions");
            p.setReview_bid("d1");
            p.setReview_rev("Excellent Question");

            db.AddReviewData(p);
        }*/

        db.close();
    }

    public void moduleask(View view) {
        startActivity(new Intent(MainActivity.this,ModuleAskQuestion.class));

        Toast.makeText(MainActivity.this, " People Ask Question", Toast.LENGTH_SHORT).show();
    }

    public void moduleans(View view) {
        startActivity(new Intent(MainActivity.this,ModuleAnswerQuestion.class));
        Toast.makeText(MainActivity.this, "Doctor Answer", Toast.LENGTH_SHORT).show();
    }

    public void modulereviewp(View view) {
        Toast.makeText(MainActivity.this, "People Feedback", Toast.LENGTH_SHORT).show();
    }

    public void modulereviewdr(View view) {
        Toast.makeText(MainActivity.this, "Doctor Expert Review", Toast.LENGTH_SHORT).show();
    }

    public void modulehelpdr(View view) {

        HelpDialogDoctor();
         //Toast.makeText(MainActivity.this, "Help Doctor", Toast.LENGTH_SHORT).show();
    }

    public void modulehelpp(View view) {
        HelpDialogPeople();
        //Toast.makeText(MainActivity.this, "Help People", Toast.LENGTH_SHORT).show();
    }

    public void  moduleLogout(View view) {
        LogoutDilaog();

    }
    public void modulefeed(View view) {
        startActivity(new Intent(MainActivity.this,ModuleFeed.class));
        Toast.makeText(MainActivity.this, "Feed ", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onBackPressed() {
        ExitDialog();
    }

    private void LogoutDilaog() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(
                "Do you want to Logout???");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Logout",
                new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        sp.edit().clear().apply();
                        startActivity(new Intent(MainActivity.this,LoginActivity.class));
                        finish();
                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void ExitDialog() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(
                "Do you want to Exit Application???");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Exit",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                         finish();

                    }
                });

        builder1.setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }


    private void HelpDialogDoctor() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(
                "Doctors can answer questions asked by patiens or the people and they can see the answers and questions in the question answer feed which display all the questions asked by people.");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
    private void HelpDialogPeople() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        builder1.setMessage(
                "People Or Patients can ask questions and they can see the answers and questions in the question answer feed which display all the questions asked by thema and other people/patients.");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });
        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
    private boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE");
        int locationPermission = ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE");

        List<String> listPermissionsNeeded = new ArrayList();
        if (locationPermission != 0) {
            listPermissionsNeeded.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (permissionSendMessage != 0) {
            listPermissionsNeeded.add("android.permission.READ_EXTERNAL_STORAGE");
        }

        if (listPermissionsNeeded.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
        return false;
    }
}

