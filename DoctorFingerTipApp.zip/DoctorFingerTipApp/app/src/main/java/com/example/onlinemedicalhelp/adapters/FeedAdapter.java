package com.example.onlinemedicalhelp.adapters;

public class FeedAdapter {
}
