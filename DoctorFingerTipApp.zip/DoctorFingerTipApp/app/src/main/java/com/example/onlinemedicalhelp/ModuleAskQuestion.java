package com.example.onlinemedicalhelp;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.onlinemedicalhelp.Database.Database;
import com.example.onlinemedicalhelp.Database.DatabaseAccess;
import com.example.onlinemedicalhelp.helper.PreferenceHelper;
import com.example.onlinemedicalhelp.helper.SharedPrefHelper;
import com.example.onlinemedicalhelp.models.PeopleModel;
import com.example.onlinemedicalhelp.models.QuestionModel;

import java.util.Calendar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import butterknife.BindView;
import butterknife.ButterKnife;

public class ModuleAskQuestion extends AppCompatActivity {

    @BindView(R.id.toolbar)
    Toolbar toolbar;


    public SharedPreferences sp;
    public SharedPrefHelper dataprocessor;

    DatabaseAccess db;
    @BindView(R.id.lblquestion)
    TextView lblquestion;
    @BindView(R.id.edtquestion)
    EditText edtquestion;
    @BindView(R.id.lblname)
    TextView lblname;
    @BindView(R.id.spinner_subque)
    Spinner spinnerSubque;
    @BindView(R.id.lblquestiondate)
    TextView lblquestiondate;
    @BindView(R.id.edtqdate)
    TextView edtqdate;
    @BindView(R.id.btnask)
    Button btnask;



    public static String subjecttype="Select Subject";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module_ask_question);
        ButterKnife.bind(this);


        toolbar.setTitle("Ask Any Queries Here");
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        edtqdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mcurrentDate=Calendar.getInstance();
                int mYear=mcurrentDate.get(Calendar.YEAR);
                int mMonth=mcurrentDate.get(Calendar.MONTH);
                int mDay=mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker=new DatePickerDialog(ModuleAskQuestion.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                        edtqdate.setText(selectedday+"/"+selectedmonth+"/"+selectedyear);
                    }
                },mYear, mMonth, mDay);
                mDatePicker.setTitle("Select date");
                mDatePicker.show();
            }
        });
        db = DatabaseAccess.getInstance(this);//new Database(ModuleAskQuestion.this);
        sp = getSharedPreferences("medical_pref", MODE_PRIVATE);
        dataprocessor = new SharedPrefHelper(ModuleAskQuestion.this);

        spinnerSubque.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                subjecttype=adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        ArrayAdapter dataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, PreferenceHelper.questionSubjects);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerSubque.setAdapter(dataAdapter);

        /*

*/


        btnask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtqdate.getText().toString().equals("")) {
                    Toast.makeText(ModuleAskQuestion.this, "Date should not be Empty", Toast.LENGTH_LONG).show();
                } else if (edtquestion.getText().toString().equals("")) {
                    Toast.makeText(ModuleAskQuestion.this, "Question should not be Empty", Toast.LENGTH_LONG).show();
                } else if (spinnerSubque.getSelectedItem().toString().equals("")) {
                    Toast.makeText(ModuleAskQuestion.this, "Subject should be Selected", Toast.LENGTH_LONG).show();
                } else {

                    PeopleModel pm = new PeopleModel();
                    db.open();
                    Log.e("TAG","email"+dataprocessor.getString(PreferenceHelper.LoginEmailid));
                    if (db.getthisPeopleData(dataprocessor.getString(PreferenceHelper.LoginEmailid)) != null) {
                        pm = db.getthisPeopleData(dataprocessor.getString(PreferenceHelper.LoginEmailid));
                    }
                    QuestionModel qm= new QuestionModel();
                    qm.setQues_date(edtqdate.getText().toString().trim());
                    qm.setQues_treviews("0");
                    qm.setQues_tanswers("0");
                    qm.setQues_sub(subjecttype);
                    qm.setQues_que(edtquestion.getText().toString().trim());
                    StringBuilder sb=new StringBuilder();
                    sb.append("p");
                    sb.append(pm.PEOPLE_ID);
                    qm.setQues_qaskid(sb.toString());
                    db.AddQuestionData(qm);
                    db.close();
                    Toast.makeText(ModuleAskQuestion.this,"Question Submitted",Toast.LENGTH_LONG).show();
                    finish();
                }
            }
            });
        }
        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            getMenuInflater();
            return super.onCreateOptionsMenu(menu);
        }

        @Override
        public boolean onOptionsItemSelected (@NonNull MenuItem item){
            if (item.getItemId() == android.R.id.home) {
                finish();
                return true;
            }
            return false;
            //return super.onOptionsItemSelected(item);
        }
    }
