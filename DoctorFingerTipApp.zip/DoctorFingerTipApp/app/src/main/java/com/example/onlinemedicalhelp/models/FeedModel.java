package com.example.onlinemedicalhelp.models;

import java.util.ArrayList;

public class FeedModel {
    String qid;
    String Question;
    String qdate;
    String qby;

    public ArrayList<FAnsModel> getListanss() {
        return listanss;
    }

    public void setListanss(ArrayList<FAnsModel> listanss) {
        this.listanss = listanss;
    }

    ArrayList<FAnsModel> listanss;



    public String getQdate() {
        return qdate;
    }

    public void setQdate(String qdate) {
        this.qdate = qdate;
    }

    public String getQby() {
        return qby;
    }

    public void setQby(String qby) {
        this.qby = qby;
    }


    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }

}
