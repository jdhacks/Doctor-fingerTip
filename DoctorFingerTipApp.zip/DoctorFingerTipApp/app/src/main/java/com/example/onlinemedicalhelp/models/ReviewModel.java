package com.example.onlinemedicalhelp.models;

public class ReviewModel {

    public Integer Review_ID;
    public String Review_sub;
    public String Review_date;
    public String Review_quid;
    public String Review_ansid;
    public String Review_bid ;
    public String Review_que;
    public String Review_ans;
    public String Review_rev;

    public String getReview_rev() {
        return Review_rev;
    }

    public void setReview_rev(String review_rev) {
        Review_rev = review_rev;
    }



    public Integer getReview_ID() {
        return Review_ID;
    }

    public void setReview_ID(Integer review_ID) {
        Review_ID = review_ID;
    }

    public String getReview_sub() {
        return Review_sub;
    }

    public void setReview_sub(String review_sub) {
        Review_sub = review_sub;
    }

    public String getReview_date() {
        return Review_date;
    }

    public void setReview_date(String review_date) {
        Review_date = review_date;
    }

    public String getReview_quid() {
        return Review_quid;
    }

    public void setReview_quid(String review_quid) {
        Review_quid = review_quid;
    }

    public String getReview_ansid() {
        return Review_ansid;
    }

    public void setReview_ansid(String review_ansid) {
        Review_ansid = review_ansid;
    }

    public String getReview_bid() {
        return Review_bid;
    }

    public void setReview_bid(String review_bid) {
        Review_bid = review_bid;
    }

    public String getReview_que() {
        return Review_que;
    }

    public void setReview_que(String review_que) {
        Review_que = review_que;
    }

    public String getReview_ans() {
        return Review_ans;
    }

    public void setReview_ans(String review_ans) {
        Review_ans = review_ans;
    }
}
