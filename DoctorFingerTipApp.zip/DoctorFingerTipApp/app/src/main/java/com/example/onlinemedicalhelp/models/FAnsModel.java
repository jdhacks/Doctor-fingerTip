package com.example.onlinemedicalhelp.models;

public class FAnsModel {
  String Answer;

    public String getAnswerid() {
        return Answerid;
    }

    public void setAnswerid(String answerid) {
        Answerid = answerid;
    }

    String Answerid;
    String Ansby;
  String AnswerDate;

    public String getAnswer() {
        return Answer;
    }

    public void setAnswer(String answer) {
        Answer = answer;
    }

    public String getAnsby() {
        return Ansby;
    }

    public void setAnsby(String ansby) {
        Ansby = ansby;
    }

    public String getAnswerDate() {
        return AnswerDate;
    }

    public void setAnswerDate(String answerDate) {
        AnswerDate = answerDate;
    }
}
