package com.example.onlinemedicalhelp.models;

public class QuestionModel {
    public Integer Ques_ID;
    public String Ques_sub;
    public String Ques_date;
    public String Ques_qaskid;
    public String Ques_que ;
    public String Ques_tanswers ;
    public String Ques_treviews;

    public Integer getQues_ID() {
        return Ques_ID;
    }

    public void setQues_ID(Integer ques_ID) {
        Ques_ID = ques_ID;
    }

    public String getQues_sub() {
        return Ques_sub;
    }

    public void setQues_sub(String ques_sub) {
        Ques_sub = ques_sub;
    }

    public String getQues_date() {
        return Ques_date;
    }

    public void setQues_date(String ques_date) {
        Ques_date = ques_date;
    }

    public String getQues_qaskid() {
        return Ques_qaskid;
    }

    public void setQues_qaskid(String ques_qaskid) {
        Ques_qaskid = ques_qaskid;
    }

    public String getQues_que() {
        return Ques_que;
    }

    public void setQues_que(String ques_que) {
        Ques_que = ques_que;
    }

    public String getQues_tanswers() {
        return Ques_tanswers;
    }

    public void setQues_tanswers(String ques_tanswers) {
        Ques_tanswers = ques_tanswers;
    }

    public String getQues_treviews() {
        return Ques_treviews;
    }

    public void setQues_treviews(String ques_treviews) {
        Ques_treviews = ques_treviews;
    }
}
