package com.example.onlinemedicalhelp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.onlinemedicalhelp.Database.Database;
import com.example.onlinemedicalhelp.Database.DatabaseAccess;
import com.example.onlinemedicalhelp.helper.PreferenceHelper;
import com.example.onlinemedicalhelp.helper.SharedPrefHelper;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.common.SignInButton;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import butterknife.BindView;
import butterknife.ButterKnife;

public class LoginActivity extends AppCompatActivity {


    public static DatabaseAccess db;
    SignInButton signInButton;
    GoogleSignInClient mGoogleSignInClient;
    @BindView(R.id.radioPeople)
    RadioButton radioPeople;
    @BindView(R.id.radioDoctor)
    RadioButton radioDoctor;
    @BindView(R.id.lblemailid)
    TextView lblemailid;
    @BindView(R.id.edtemailid)
    EditText edtemailid;
    @BindView(R.id.lblpass)
    TextView lblpass;
    @BindView(R.id.edtname)
    EditText edtname;
    @BindView(R.id.btnLogin)
    Button btnLogin;
    @BindView(R.id.btnsignup)
    Button btnsignup;

    public static SharedPreferences sp;
    public static SharedPrefHelper dataProcessor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);


        db =DatabaseAccess.getInstance(this);// new Database(LoginActivity.this);
        sp= getSharedPreferences("medical_prefs",MODE_PRIVATE);
        dataProcessor= new SharedPrefHelper(LoginActivity.this);

        radioPeople.setChecked(true);
        radioDoctor.setChecked(false);

     /*   radioDoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean checked = radioDoctor.isChecked();
                // Check which radiobutton was pressed
                if (checked){
                    // Do your coding
                    radioDoctor.setChecked(false);
                    radioPeople.setChecked(true);
                }
                else{
                    radioDoctor.setChecked(true);
                    // Do your coding
                }
            }
        });


        radioPeople.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean checked = radioPeople.isChecked();
                // Check which radiobutton was pressed
                if (checked){
                    // Do your coding
                    radioPeople.setChecked(false);
                }
                else{
                    radioPeople.setChecked(true);
                    // Do your coding
                }
            }
        });
*/


        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(radioDoctor.isChecked() || radioPeople.isChecked())
                {
                    if(radioPeople.isChecked())
                    {
                        startActivity(new Intent(LoginActivity.this,SignUpActivity.class));
                    }else{
                        startActivity(new Intent(LoginActivity.this,DoctorSignUpActivity.class));
                    }

                }else{
                    Toast.makeText(LoginActivity.this,"Please Select One From People/Doctor",Toast.LENGTH_LONG).show();
                }
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!radioDoctor.isChecked() && !radioPeople.isChecked()) {
                    Toast.makeText(LoginActivity.this,"Please Select One From People/Doctor",Toast.LENGTH_LONG).show();

                } else  if(edtemailid.getText().toString().trim().equals(""))
                {
                    Toast.makeText(LoginActivity.this,"Please Enter Valid Email Id",Toast.LENGTH_LONG).show();
                }else if(edtname.getText().toString().trim().equals(""))
                {
                    Toast.makeText(LoginActivity.this,"Please Enter Valid Password",Toast.LENGTH_LONG).show();
                }else {
                    db.open();
                    if(radioPeople.isChecked()){
                    if (db.getPeopleLogin(edtemailid.getText().toString().trim(),edtname.getText().toString().trim())) {
                        dataProcessor.setString(PreferenceHelper.LOGINTYPE,PreferenceHelper.TYPEPEOPLE);
                        dataProcessor.setString(PreferenceHelper.LoginEmailid,edtemailid.getText().toString().trim());
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    }else {
                        if (db.getPeopleExits(edtemailid.getText().toString().trim()))
                        {
                            Toast.makeText(LoginActivity.this,"Wrong Email Id or Password",Toast.LENGTH_LONG).show();

                        }else {
                            Toast.makeText(LoginActivity.this, "No Email ID Found", Toast.LENGTH_LONG).show();
                        }
                    }}else{
                        if (db.getDoctorLogin(edtemailid.getText().toString().trim(),edtname.getText().toString().trim())) {
                            dataProcessor.setString(PreferenceHelper.LOGINTYPE,PreferenceHelper.TYPEDOC);
                            dataProcessor.setString(PreferenceHelper.LoginEmailid,edtemailid.getText().toString().trim());
                            startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        }else {
                            if (db.getDoctorExits(edtemailid.getText().toString().trim()))
                            {
                                Toast.makeText(LoginActivity.this,"Wrong Email Id or Password",Toast.LENGTH_LONG).show();

                            }else {
                                Toast.makeText(LoginActivity.this, "No Email ID Found", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                    db.close();
                }
                }
        });

        /*GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
       // updateUI(account);
        signInButton = findViewById(R.id.sign_in_button);
        signInButton.setSize(SignInButton.SIZE_STANDARD);
 */
    }

    private boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE");
        int locationPermission = ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE");

        List<String> listPermissionsNeeded = new ArrayList();
        if (locationPermission != 0) {
            listPermissionsNeeded.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (permissionSendMessage != 0) {
            listPermissionsNeeded.add("android.permission.READ_EXTERNAL_STORAGE");
        }

        if (listPermissionsNeeded.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), 1);
        return false;
    }
}
